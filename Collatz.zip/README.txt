Course Name: Generic Programming and the STL
Unique: 91060
First Name: Nathan
Last Name: Friedman
EID: nsf
CS Username: nsf
GitHub ID: nathansfriedman
GitHub Repository Name: cs378-collatz
Estimated number of hours: 15
Actual number of hours: 20
Comments: Was able to get submissions to both Sphere tests accepted.
Turning in project1 one day late.

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.


